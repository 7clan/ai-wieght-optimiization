// harness-provided seed data (labeled): demo plants for Greenhouse
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
async function main() {
  await db.plant.deleteMany()
  await db.watering.deleteMany()
  await db.plant.createMany({ data: [
    { id: 'seed-plant-1', name: 'Fern', moisture: 22, room: 'Front' },
    { id: 'seed-plant-2', name: 'Cactus', moisture: 65, room: 'Back' },
    { id: 'seed-plant-3', name: 'Orchid', moisture: 31, room: 'Front' },
  ]})
  await db.watering.createMany({ data: [
    { amount: 200, plantId: 'seed-plant-1' },
    { amount: 50, plantId: 'seed-plant-2' },
  ]})
  console.log('reseeded 3 plants, 2 waterings')
}
main().finally(() => db.$disconnect())
