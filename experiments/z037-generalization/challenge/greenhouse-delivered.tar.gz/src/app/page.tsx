'use client'

// TEACHER-PASS (Session 037 Phase 11, disclosed): the engine failed the
// page piece 4/4 attempts in run-2.  Attempt-0 (archive
// challenge/gen/gh-page-exact_shape-0-501500.json) produced an on-spec
// skeleton (load()/loading/error states around fetch('/api/plants'))
// before early-EOS truncation; this page keeps that skeleton's
// structure and fills the spec's remaining clauses.  The needsWater
// badge consumes the model-authored invariant; data comes from the
// model-authored schema via the teacher routes.
// Attribution: skeleton-structure = model-influenced; code = teacher.

import { useEffect, useState } from 'react'
import { needsWater } from '@/lib/greenhouse/invariants'

type Plant = {
  id: string
  name: string
  moisture: number
  room: string
}

export default function GreenhousePage() {
  const [plants, setPlants] = useState<Plant[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [plantId, setPlantId] = useState('')
  const [amount, setAmount] = useState('')
  const [formError, setFormError] = useState('')
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/plants')
      if (!res.ok) throw new Error('failed')
      const data = await res.json()
      setPlants(data.plants)
      setError('')
    } catch {
      setError('Could not load plants')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const addWatering = async () => {
    setFormError('')
    setSaving(true)
    try {
      const res = await fetch('/api/waterings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plantId,
          amount: Number(amount),
        }),
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        setFormError(data.error ?? 'Failed to add watering')
        return
      }
      await load()
    } finally {
      setSaving(false)
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-2xl font-bold">Plants</h1>

      {loading ? (
        <p className="mt-4 text-muted-foreground">Loading…</p>
      ) : error ? (
        <div className="mt-4">
          <p className="text-red-600">{error}</p>
          <button
            onClick={load}
            className="mt-2 rounded-md border px-3 py-1.5 text-sm"
          >
            Retry
          </button>
        </div>
      ) : (
        <>
          <ul className="mt-4 divide-y">
            {plants.map((p) => (
              <li key={p.id} className="flex items-center gap-3 py-3">
                <span className="font-medium">{p.name}</span>
                <span className="text-sm text-muted-foreground">
                  {p.room} · moisture {p.moisture}
                </span>
                {needsWater(p.moisture) ? (
                  <span className="rounded bg-amber-100 px-2 py-0.5 text-xs text-amber-800">
                    needs water
                  </span>
                ) : null}
              </li>
            ))}
          </ul>

          <section className="mt-8 rounded-lg border p-4">
            <h2 className="font-semibold">Add watering</h2>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <select
                aria-label="Plant"
                value={plantId}
                onChange={(e) => setPlantId(e.target.value)}
                className="rounded-md border px-2 py-1.5 text-sm"
              >
                <option value="">select plant…</option>
                {plants.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              <input
                aria-label="Amount"
                placeholder="Amount (ml)"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-32 rounded-md border px-2 py-1.5 text-sm"
              />
              <button
                onClick={addWatering}
                disabled={saving || !plantId || !amount}
                className="rounded-md bg-primary px-3 py-1.5 text-sm text-primary-foreground disabled:opacity-50"
              >
                Add watering
              </button>
            </div>
            {formError ? (
              <p className="mt-2 text-sm text-red-600">{formError}</p>
            ) : null}
          </section>
        </>
      )}
    </main>
  )
}
