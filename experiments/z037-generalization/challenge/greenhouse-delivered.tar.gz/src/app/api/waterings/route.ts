// TEACHER-PASS (Session 037 Phase 11, disclosed): the engine failed
// this route in both challenge runs; POST routes with multi-branch
// validation resolved only 1/6 across all four tracks.  Written per
// SPEC.json clauses (frozen sha 32ac3b42).
// Attribution: 100% teacher.

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  const body = await request.json()
  const amount = Number(body.amount)
  if (!Number.isInteger(amount) || amount < 1 || amount > 500) {
    return NextResponse.json(
      { error: 'Amount must be 1-500' }, { status: 400 })
  }
  const plant = await db.plant.findUnique({
    where: { id: body.plantId },
  })
  if (!plant) {
    return NextResponse.json(
      { error: 'Plant not found' }, { status: 404 })
  }
  const watering = await db.watering.create({
    data: { amount, plantId: body.plantId },
  })
  return NextResponse.json({ watering }, { status: 201 })
}
