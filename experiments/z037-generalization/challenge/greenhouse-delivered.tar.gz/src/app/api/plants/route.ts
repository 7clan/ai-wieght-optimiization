// TEACHER-PASS (Session 037 Phase 11, disclosed): the engine failed
// this route in both challenge runs and GET search-filter routes went
// 0/4 tracks in the four-track comparison (universal gap at 0.5B).
// Written per SPEC.json clauses (frozen sha 32ac3b42); no model bytes
// survived the gate loop to preserve (candidates were Express-style
// signatures or stubs — see challenge/gen/gh-get-plants-*.json).
// Attribution: 100% teacher.

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const q = searchParams.get('q')
  const plants = await db.plant.findMany({
    where: q ? { name: { contains: q } } : undefined,
  })
  return NextResponse.json({ plants })
}
