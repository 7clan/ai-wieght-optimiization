// TEACHER-PASS (Session 037 Phase 11, disclosed): the engine loop
// failed this piece 7/7 in both challenge runs — but attempt-0 of run-2
// (archive gen/gh-needswater-exact_shape-0-500600.json) contains the
// model's own correct expression `return moisture < 30`.  This file
// assembles the model's expression with the spec signature; the syntax
// cleanup (removing prompt-echo, closing the construct) is the teacher's.
// Attribution: expression = model-authored; assembly = teacher.

export function needsWater(moisture: number): boolean {
  return moisture < 30
}
